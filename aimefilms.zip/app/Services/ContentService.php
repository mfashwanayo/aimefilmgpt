<?php
declare(strict_types=1);

final class ContentService
{
    public function __construct(private PDO $db) {}

    public function create(int $artistId, array $data, array $paths): int
    {
        $title=trim((string)($data['title']??''));
        $type=(string)($data['content_type']??'');
        $platform=(string)($data['platform']??'');
        $allowedTypes=['movie','series','episode','music_video','album','single'];
        $allowedPlatforms=['aimefilms','filmsnyarwanda','musicspart'];
        if ($title==='' || mb_strlen($title)>180) throw new InvalidArgumentException('Title is required and must be under 180 characters.');
        if (!in_array($type,$allowedTypes,true) || !in_array($platform,$allowedPlatforms,true)) throw new InvalidArgumentException('Choose a valid platform and content type.');
        if (($platform==='musicspart' && !in_array($type,['album','single','music_video'],true)) ||
            ($platform==='filmsnyarwanda' && !in_array($type,['movie','series','episode','music_video'],true))) {
            throw new InvalidArgumentException('That content type is not available on the selected platform.');
        }
        $slug=$this->slug($title).'-'.bin2hex(random_bytes(4));
        $parent=filter_var($data['parent_id']??null,FILTER_VALIDATE_INT) ?: null;
        if ($parent) {
            $p=$this->db->prepare('SELECT id FROM artist_content WHERE id=? AND artist_user_id=? AND content_type IN (\'series\',\'album\')');
            $p->execute([$parent,$artistId]);
            if (!$p->fetch()) throw new InvalidArgumentException('Select a valid series or album belonging to your account.');
        }
        $q=$this->db->prepare("INSERT INTO artist_content
          (artist_user_id,platform,content_type,title,slug,description,release_date,language,genre,duration_seconds,media_path,poster_path,thumbnail_path,cover_path,parent_id,visibility)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending')");
        $q->execute([$artistId,$platform,$type,$title,$slug,trim((string)($data['description']??'')),
          ($data['release_date']??'') ?: null,trim((string)($data['language']??'')) ?: null,
          trim((string)($data['genre']??'')) ?: null,filter_var($data['duration_seconds']??null,FILTER_VALIDATE_INT) ?: null,
          $paths['media']??null,$paths['poster']??null,$paths['thumbnail']??null,$paths['cover']??null,$parent]);
        return (int)$this->db->lastInsertId();
    }

    public function ownContent(int $artistId): array
    {
        $q=$this->db->prepare('SELECT * FROM artist_content WHERE artist_user_id=? ORDER BY created_at DESC');
        $q->execute([$artistId]); return $q->fetchAll(PDO::FETCH_ASSOC);
    }

    public function deleteDraft(int $id,int $artistId): void
    {
        $q=$this->db->prepare("DELETE FROM artist_content WHERE id=? AND artist_user_id=? AND visibility IN ('draft','rejected')");
        $q->execute([$id,$artistId]);
        if (!$q->rowCount()) throw new RuntimeException('Only your own draft or rejected content can be deleted.');
    }

    private function slug(string $value): string
    {
        $value=iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$value) ?: $value;
        $value=strtolower(trim(preg_replace('/[^a-z0-9]+/','-',$value),'-'));
        return $value ?: 'content';
    }
}
