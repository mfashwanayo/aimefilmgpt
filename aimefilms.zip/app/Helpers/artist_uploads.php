<?php
declare(strict_types=1);

function artist_upload(array $file, string $kind, int $userId): ?string
{
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) return null;
    if ($file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Upload failed. Please try again.');
    $rules = [
      'image'=>['jpg','jpeg','png','webp','image/jpeg','image/png','image/webp',5*1024*1024],
      'video'=>['mp4','webm','video/mp4','video/webm',500*1024*1024],
      'audio'=>['mp3','m4a','wav','audio/mpeg','audio/mp4','audio/wav',100*1024*1024]
    ];
    if (!isset($rules[$kind])) throw new RuntimeException('Unsupported upload type.');
    [$a,$b,$c,$d,$e]=$rules[$kind];
    $ext=strtolower(pathinfo($file['name']??'',PATHINFO_EXTENSION));
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $allowedExt=array_slice($rules[$kind],0, $kind==='image'?3:($kind==='video'?2:3));
    $allowedMime=array_slice($rules[$kind], $kind==='image'?3:($kind==='video'?2:3), $kind==='image'?3:($kind==='video'?2:3));
    $max=end($rules[$kind]);
    if (!in_array($ext,$allowedExt,true) || !in_array($mime,$allowedMime,true) || $file['size']>$max) {
        throw new RuntimeException('Invalid file type or size for this upload.');
    }
    $root=dirname(__DIR__,2).'/public/uploads/artists/'.$userId;
    if (!is_dir($root) && !mkdir($root,0750,true) && !is_dir($root)) throw new RuntimeException('Cannot create upload directory.');
    $name=bin2hex(random_bytes(16)).'.'.$ext;
    if (!move_uploaded_file($file['tmp_name'],$root.'/'.$name)) throw new RuntimeException('Could not save uploaded file.');
    return 'uploads/artists/'.$userId.'/'.$name;
}
