<?php
$pageTitle = 'AIMEFILMS Originals — AIMEFILMS';
$activePlatform = 'aimefilms';
$base = '../';
require __DIR__ . '/../partials/header.php';
?>
<main>
<section class="subhero original-hero"><div class="subhero-copy"><span class="eyebrow"><span class="eyebrow-dot"></span>AIMEFILMS ORIGINALS</span><h1>Original ideas.<br><span>Stories without limits.</span></h1><p>A home for original productions, exclusive releases and bold creative voices from Rwanda and beyond.</p><div class="hero-actions"><a class="btn btn-primary" href="../auth/register.php">Join and explore <span>→</span></a><a class="btn btn-glass" href="../auth/login.php">I already have an account</a></div></div><div class="subhero-symbol">✦</div></section>
<section class="section"><div class="section-heading"><div><span class="eyebrow">START EXPLORING</span><h2>Discover what’s <span>playing.</span></h2></div><p>These sections are ready for dynamic content when we connect the database and creator catalogue.</p></div><div class="content-grid"><article class="content-card"><div class="content-art art-1"><span>AIME ORIGINALS</span><b>✦</b></div><div class="content-card-body"><small>ORIGINAL PRODUCTIONS</small><h3>Original films</h3><p>Explore stories created and produced under the AIMEFILMS banner.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article>
<article class="content-card"><div class="content-art art-2"><span>BEHIND THE SCENES</span><b>◉</b></div><div class="content-card-body"><small>EXCLUSIVE CONTENT</small><h3>Behind the scenes</h3><p>Go beyond the screen with production stories and creative journeys.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article>
<article class="content-card"><div class="content-art art-3"><span>CREATIVE COMMUNITY</span><b>＋</b></div><div class="content-card-body"><small>FILMMAKERS</small><h3>Meet the creators</h3><p>Connect with directors, writers, producers and production teams.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article></div></section>
<section class="mini-cta"><div><span class="eyebrow">BE PART OF THE COMMUNITY</span><h2>Your account opens the door.</h2><p>Save favourites, follow creators and get closer to the stories you love.</p></div><a class="btn btn-primary" href="../auth/register.php">Create free account →</a></section>
</main>
<?php require __DIR__ . '/../partials/footer.php'; ?>