<?php
$pageTitle = 'MusicSpart — AIMEFILMS';
$activePlatform = 'musicspart';
$base = '../';
require __DIR__ . '/../partials/header.php';
?>
<main>
<section class="subhero music-hero"><div class="subhero-copy"><span class="eyebrow"><span class="eyebrow-dot"></span>RWANDAN MUSIC & ARTISTS</span><h1>Find your rhythm.<br><span>Feel the next sound.</span></h1><p>Discover artists, albums, singles and music videos while exploring the voices shaping the sound of Rwanda.</p><div class="hero-actions"><a class="btn btn-primary" href="../auth/register.php">Join and explore <span>→</span></a><a class="btn btn-glass" href="../auth/login.php">I already have an account</a></div></div><div class="subhero-symbol">♫</div></section>
<section class="section"><div class="section-heading"><div><span class="eyebrow">START EXPLORING</span><h2>Discover what’s <span>playing.</span></h2></div><p>These sections are ready for dynamic content when we connect the database and creator catalogue.</p></div><div class="content-grid"><article class="content-card"><div class="content-art art-1"><span>ARTIST SPOTLIGHT</span><b>♫</b></div><div class="content-card-body"><small>ARTISTS</small><h3>Discover artists</h3><p>Find new voices, follow your favourites and explore their work.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article>
<article class="content-card"><div class="content-art art-2"><span>FRESH RELEASES</span><b>◉</b></div><div class="content-card-body"><small>MUSIC & ALBUMS</small><h3>Albums & singles</h3><p>Explore music releases and build your personal listening library.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article>
<article class="content-card"><div class="content-art art-3"><span>WATCH & DISCOVER</span><b>▶</b></div><div class="content-card-body"><small>MUSIC VIDEOS</small><h3>Music videos</h3><p>Experience the visuals behind the sound.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article></div></section>
<section class="mini-cta"><div><span class="eyebrow">BE PART OF THE COMMUNITY</span><h2>Your account opens the door.</h2><p>Save favourites, follow creators and get closer to the stories you love.</p></div><a class="btn btn-primary" href="../auth/register.php">Create free account →</a></section>
</main>
<?php require __DIR__ . '/../partials/footer.php'; ?>