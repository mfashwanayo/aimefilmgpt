<?php
require_once dirname(__DIR__,2).'/app/bootstrap.php';
require_once dirname(__DIR__,2).'/app/Services/ArtistService.php';
require_once dirname(__DIR__,2).'/app/Services/ContentService.php';
require_auth();$user=current_user();$db=Database::connection();
$profile=(new ArtistService($db))->profile((int)$user['id']);
if(!$profile || $profile['verification_status']!=='approved'){http_response_code(403);exit('Verified artist access required.');}
$service=new ContentService($db);
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf_or_abort();try{$service->deleteDraft((int)($_POST['id']??0),(int)$user['id']);flash('success','Content deleted.');}catch(Throwable $e){flash('error',$e->getMessage());}header('Location: content.php');exit;}
$items=$service->ownContent((int)$user['id']);
require dirname(__DIR__).'/partials/header.php'; ?>
<main class="container" style="padding:40px 20px"><h1>Manage content</h1><p><a href="content-create.php">+ Upload new content</a></p>
<div style="overflow-x:auto"><table><thead><tr><th>Title</th><th>Platform</th><th>Type</th><th>Status</th><th>Views</th><th>Created</th><th>Action</th></tr></thead><tbody>
<?php foreach($items as $item):?><tr><td><?=e($item['title'])?></td><td><?=e($item['platform'])?></td><td><?=e($item['content_type'])?></td><td><?=e($item['visibility'])?></td><td><?=number_format((int)$item['views_count'])?></td><td><?=e($item['created_at'])?></td><td><?php if(in_array($item['visibility'],['draft','rejected'],true)):?><form method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$item['id']?>"><button type="submit">Delete</button></form><?php else:?>—<?php endif;?></td></tr><?php endforeach;?>
<?php if(!$items):?><tr><td colspan="7">No content uploaded yet.</td></tr><?php endif;?></tbody></table></div></main>
<?php require dirname(__DIR__).'/partials/footer.php'; ?>
