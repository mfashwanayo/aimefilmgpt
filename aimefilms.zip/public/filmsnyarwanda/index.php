<?php
$pageTitle = 'FilmsNyarwanda — AIMEFILMS';
$activePlatform = 'filmsnyarwanda';
$base = '../';
require __DIR__ . '/../partials/header.php';
?>
<main>
<section class="subhero films-hero"><div class="subhero-copy"><span class="eyebrow"><span class="eyebrow-dot"></span>RWANDAN FILM & SERIES DISCOVERY</span><h1>Rwandan stories.<br><span>Ready to be discovered.</span></h1><p>Explore movies, series, trailers and the talented actors, directors and filmmakers shaping Rwandan cinema.</p><div class="hero-actions"><a class="btn btn-primary" href="../auth/register.php">Join and explore <span>→</span></a><a class="btn btn-glass" href="../auth/login.php">I already have an account</a></div></div><div class="subhero-symbol">▶</div></section>
<section class="section"><div class="section-heading"><div><span class="eyebrow">START EXPLORING</span><h2>Discover what’s <span>playing.</span></h2></div><p>These sections are ready for dynamic content when we connect the database and creator catalogue.</p></div><div class="content-grid"><article class="content-card"><div class="content-art art-1"><span>FEATURED FILMS</span><b>▶</b></div><div class="content-card-body"><small>MOVIES</small><h3>Rwandan movies</h3><p>Discover memorable stories from established and emerging filmmakers.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article>
<article class="content-card"><div class="content-art art-2"><span>NEW EPISODES</span><b>▣</b></div><div class="content-card-body"><small>SERIES</small><h3>Series & episodes</h3><p>Follow stories that unfold episode by episode.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article>
<article class="content-card"><div class="content-art art-3"><span>MEET THE CREATORS</span><b>✦</b></div><div class="content-card-body"><small>PEOPLE</small><h3>Actors & directors</h3><p>Get to know the talent bringing every story to life.</p><a class="text-link" href="../auth/register.php">Discover more <b>↗</b></a></div></article></div></section>
<section class="mini-cta"><div><span class="eyebrow">BE PART OF THE COMMUNITY</span><h2>Your account opens the door.</h2><p>Save favourites, follow creators and get closer to the stories you love.</p></div><a class="btn btn-primary" href="../auth/register.php">Create free account →</a></section>
</main>
<?php require __DIR__ . '/../partials/footer.php'; ?>